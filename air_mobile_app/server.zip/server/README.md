chmod +x run_server.sh  # Make it executable
./run_server.sh save    # Run in save mode
./run_server.sh window  # Run in window mode
./run_server.sh none    # Run in none mode